package com.example.cloudproject;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.List;

public class productAdapClass extends ArrayAdapter<product> {

    public productAdapClass(@NonNull Context context, int resource, @NonNull List<product> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        product pro = getItem(position);
        ViewHolder viewHolder = new ViewHolder();

        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_product_adaptor, parent, false);
            viewHolder= new ViewHolder();
            viewHolder.imageUrl = (ImageView) convertView.findViewById(R.id.productImg);
            viewHolder.description = (TextView) convertView.findViewById(R.id.description);
            viewHolder.title = (TextView) convertView.findViewById(R.id.titleView);
            viewHolder.price = (TextView) convertView.findViewById(R.id.price);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        if (pro.description.equals("null") || pro.description.isEmpty()){
            viewHolder.description.setText("");
        }
        else {
            viewHolder.description.setText(pro.description);
        }

        if (pro.title.equals("null") || pro.title.isEmpty()){
            viewHolder.title.setText("");
        }
        else {
            viewHolder.title.setText(pro.title);
        }

        if (pro.price.equals("null") ){
            viewHolder.price.setText("");
        }
        else {
            viewHolder.price.setText(pro.price.toString());
        }

        Picasso.get().load(pro.imageUrl).into(viewHolder.imageUrl);

        return convertView;

    }

        static class ViewHolder {
        ImageView imageUrl;
        TextView title;
        TextView description;
        TextView price;

    }
}
