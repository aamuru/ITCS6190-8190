package com.example.cloudproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import static java.lang.Float.parseFloat;

public class MainActivity extends AppCompatActivity {

    TextView search;
    Button searchBtn;
    ListView recomList;
    ProgressBar recomProgressbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        search = findViewById(R.id.search);
        searchBtn = findViewById(R.id.searchBtn);
        recomList = findViewById(R.id.recomListview);
        recomProgressbar = findViewById(R.id.comProgrssbar);

        new getRecom().execute("https://clouldsearchengine.herokuapp.com/");

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String serachword = search.getText().toString();

                Intent intent = new Intent(MainActivity.this,searchList.class);
                intent.putExtra("searachKey",serachword);
//                new getSearch().execute("https://clouldsearchengine.herokuapp.com/search/"+URLEncoder.encode(q, "UTF-8") );
                startActivity(intent);
            }
        });




    }

    private class getRecom extends AsyncTask<String,Void, ArrayList<product>> {

        @Override
        protected void onPostExecute(ArrayList<product> products) {

            recomList = (ListView) findViewById(R.id.recomListview);
            recomProgressbar = findViewById(R.id.comProgrssbar);

            productAdapClass adapter = new productAdapClass(MainActivity.this, R.layout.activity_product_adaptor, products);
            recomList.setAdapter(adapter);

        }

        @Override
        protected ArrayList<product> doInBackground(String... strings) {
            HttpURLConnection connection = null;
            ArrayList<product> arraynews = new ArrayList<>();
            try {
                URL url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");
                    JSONArray root = new JSONArray(json);
                    for (int i=0;i<root.length();i++) {
                        JSONObject articleJson = root.getJSONObject(i);
                        product article = new product();
                        article.title= "";
                        JSONObject jsonobj = articleJson.getJSONObject("_3");
                        article.price= parseFloat(articleJson.getString("_2"));
                        article.description = articleJson.getString("_1");
                        if (jsonobj != null ){
                            article.imageUrl = jsonobj.getString("_5");
                            article.website = jsonobj.getString("_6");
                        }else{
                            article.imageUrl = "";
                            article.website = "";
                        }
                        arraynews.add(article);
                    }
                }
            } catch (Exception e) {
                Log.d("exception",e.toString());
            } finally {
                //Close the connections
            }
            return arraynews;
        }
    }


}
