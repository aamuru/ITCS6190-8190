package com.example.cloudproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class productAdaptor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_adaptor);
    }
}
