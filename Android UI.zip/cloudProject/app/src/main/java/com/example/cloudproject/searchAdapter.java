package com.example.cloudproject;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.List;

public class searchAdapter extends ArrayAdapter<product> {
    public searchAdapter(@NonNull Context context, int resource, @NonNull List<product> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Log.d("productydetails", "Ravi is here");
        product pro = getItem(position);

        searchViewholder viewholder;


        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_search_list_adapter, parent, false);
            viewholder = new searchViewholder();
            viewholder.imageUrls = (ImageView) convertView.findViewById(R.id.productSImg);
            viewholder.descriptions= (TextView) convertView.findViewById(R.id.descriptionS);
            viewholder.titles = (TextView) convertView.findViewById(R.id.titleSView);
            viewholder.prices = (TextView) convertView.findViewById(R.id.priceS);
            viewholder.logos = (ImageView) convertView.findViewById(R.id.logo);
            convertView.setTag(viewholder);
        }else{
            viewholder = (searchViewholder) convertView.getTag();
        }

        if (pro.price.equals("null")){
            viewholder.prices.setText("");
        }
        else {
            viewholder.prices.setText(pro.price+"");
        }

        if (pro.title.equals("null") || pro.title.isEmpty()){
            viewholder.descriptions.setText("");
        }
        else {
            viewholder.descriptions.setText(pro.title);
        }

        if (pro.website.equals("null") || pro.website.isEmpty()){

        }
        else {

            if (pro.website.equals("amazon.com"))
                viewholder.logos.setImageResource(R.drawable.amazon);
            else if (pro.website.equals("wallmart.com"))
               viewholder.logos.setImageResource(R.drawable.walmart);
        }


        Picasso.get().load(pro.imageUrl).into(viewholder.imageUrls);


        return convertView;
    }





    private class searchViewholder {
        ImageView imageUrls;
        TextView titles;
        TextView descriptions;
        TextView prices;
        ImageView logos;
    }

}
