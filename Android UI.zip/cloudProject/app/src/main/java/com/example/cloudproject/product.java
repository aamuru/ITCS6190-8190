package com.example.cloudproject;

public class product {

    String title;
    String imageUrl;
    Float price;
    String website;
    String description;

    @Override
    public String toString() {
        return "product{" +
                "title='" + title + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", price=" + price +
                ", website='" + website + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
