package com.example.cloudproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Float.parseFloat;

public class searchList extends AppCompatActivity {

    ListView searchList;
    String val;
    ProgressBar progressBar2;
    Spinner sortSpinner;
    String sortBy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_list);


//        progressBar2 = findViewById(R.id.progressBar2);
//        progressBar2.setVisibility(View.VISIBLE);
        searchList = findViewById(R.id.searchList);
        sortSpinner = findViewById(R.id.sortBySpinner);

        List<String> list = new ArrayList<String>();
        list.add("all");
        list.add("Amazon");
        list.add("Walmart");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sortSpinner.setAdapter(dataAdapter);

        sortBy ="all";
        val = getIntent().getExtras().getString("searachKey");

        sortSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d("onselct","integer:"+i+ "  "+sortBy);

                if (i == 1){
                    sortBy = "amazon";
                    try {
                        URL url = new URL("https://clouldsearchengine.herokuapp.com/search/" + URLEncoder.encode(val, "UTF-8").replace("+", "%20"));
                        new getSearch().execute(String.valueOf(url));
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }else if (i==2){
                    sortBy ="walmart";
                    try {
                        URL url = new URL("https://clouldsearchengine.herokuapp.com/search/" + URLEncoder.encode(val, "UTF-8").replace("+", "%20"));
                        new getSearch().execute(String.valueOf(url));
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }else{
                    sortBy ="all";
                    try {
                        URL url = new URL("https://clouldsearchengine.herokuapp.com/search/" + URLEncoder.encode(val, "UTF-8").replace("+", "%20"));
                        new getSearch().execute(String.valueOf(url));
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });




        try {
            URL url = new URL("https://clouldsearchengine.herokuapp.com/search/" + URLEncoder.encode(val, "UTF-8").replace("+", "%20"));
            new getSearch().execute(String.valueOf(url));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }


//        progressBar2.setVisibility(View.GONE);


    }

    private class getSearch extends AsyncTask<String,Void, ArrayList<product>> {

        @Override
        protected void onPostExecute(ArrayList<product> products) {

            searchList = (ListView) findViewById(R.id.searchList);

            searchAdapter adapter = new searchAdapter(searchList.this, R.layout.activity_search_list_adapter, products);
            Log.d("check",products.size()+" elements");
            searchList.setAdapter(adapter);




        }

        @Override
        protected ArrayList<product> doInBackground(String... strings) {
            HttpURLConnection connection = null;
            ArrayList<product> arraynews = new ArrayList<>();
            try {
                URL url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");
                    JSONArray root = new JSONArray(json);
                    Log.d("sortby","Sort by:" + sortBy);
                    Log.d("URL","URL by:" + url);
                    if (sortBy.equals("all")){
                        for (int i=0;i<root.length();i++) {
                            JSONObject articleJson = root.getJSONObject(i);
                            product article = new product();
                            article.title= "";
                            JSONArray urlobj = articleJson.getJSONArray("imageUrl");
                            article.imageUrl = urlobj.getString(0);
                            JSONArray priceobj = articleJson.getJSONArray("priceWhole");
                            if(priceobj != null && priceobj.length() > 0 ){
                                article.price =  parseFloat(priceobj.get(0)+"");

                            }else {
                                article.price = parseFloat("0");
                            }
                            article.description = "";
                            JSONArray titleobj = articleJson.getJSONArray("titleText");
                            if (titleobj != null){
                                article.title = titleobj.get(0)+"";
                            }else{
                                article.title = "";
                            }
                            article.website= articleJson.getString("website");
                            arraynews.add(article);
//                        Log.d("list",url +"");
//                        Log.d("list",arraynews.size() +"");
                        }
                    }else if (sortBy.equals("amazon")){
                        Log.d("check1","he is here");
                        for (int i=0;i<root.length();i++) {
                            JSONObject articleJson = root.getJSONObject(i);
                            String SortBy = articleJson.getString("website");
                            if (SortBy.equals("amazon.com")){
                                product article = new product();
                                article.title= "";
                                article.website= articleJson.getString("website");
                                JSONArray urlobj = articleJson.getJSONArray("imageUrl");
                                article.imageUrl = urlobj.getString(0);
                                JSONArray priceobj = articleJson.getJSONArray("priceWhole");
                                if(priceobj != null && priceobj.length() > 0 ){
                                    article.price =  parseFloat(priceobj.get(0)+"");

                                }else {
                                    article.price = parseFloat("0");
                                }
                                article.description = "";
                                JSONArray titleobj = articleJson.getJSONArray("titleText");
                                if (titleobj != null){
                                    article.title = titleobj.get(0)+"";
                                }else{
                                    article.title = "";
                                }
                                article.website = SortBy;

                                arraynews.add(article);
                            }
                        }
                    }else if (sortBy.equals("walmart")){
                        for (int i=0;i<root.length();i++) {
                            Log.d("check1","he is here walmart");
                            JSONObject articleJson = root.getJSONObject(i);
                            String SortBy = articleJson.getString("website");

                            if (SortBy.equals("wallmart.com")){
                                Log.d("website", SortBy+"Yeys");
                                product article = new product();
                                article.title= "";
                                article.website= articleJson.getString("website");
                                JSONArray urlobj = articleJson.getJSONArray("imageUrl");
                                article.imageUrl = urlobj.getString(0);
                                JSONArray priceobj = articleJson.getJSONArray("priceWhole");
                                if(priceobj != null && priceobj.length() > 0 ){
                                    article.price =  parseFloat(priceobj.get(0)+"");

                                }else {
                                    article.price = parseFloat("0");
                                }
                                article.description = "";
                                JSONArray titleobj = articleJson.getJSONArray("titleText");
                                if (titleobj != null){
                                    article.title = titleobj.get(0)+"";
                                }else{
                                    article.title = "";
                                }
                                article.website = SortBy;

                                arraynews.add(article);
                            }
                        }

                    }

                }
            } catch (Exception e) {
                Log.d("exception",e.toString());
            } finally {
                //Close the connections
            }
            return arraynews;
        }
    }
}
